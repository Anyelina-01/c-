﻿namespace App_de_Loteria
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtBoxApostado = new TextBox();
            txtBoxGanado = new TextBox();
            label1 = new Label();
            label3 = new Label();
            label6 = new Label();
            label2 = new Label();
            label7 = new Label();
            label8 = new Label();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            label9 = new Label();
            label4 = new Label();
            label11 = new Label();
            label10 = new Label();
            btnPlay = new Button();
            groupBox1 = new GroupBox();
            rdbtnPale = new RadioButton();
            rdbtnPaleDoble = new RadioButton();
            label5 = new Label();
            textBox3 = new TextBox();
            labelResultado3 = new Label();
            labelResultado2 = new Label();
            labelResultado1 = new Label();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // txtBoxApostado
            // 
            txtBoxApostado.Font = new Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            txtBoxApostado.Location = new Point(289, 27);
            txtBoxApostado.Multiline = true;
            txtBoxApostado.Name = "txtBoxApostado";
            txtBoxApostado.Size = new Size(104, 38);
            txtBoxApostado.TabIndex = 7;
            txtBoxApostado.Text = "0";
            txtBoxApostado.TextAlign = HorizontalAlignment.Right;
            // 
            // txtBoxGanado
            // 
            txtBoxGanado.Font = new Font("Segoe UI", 21.75F, FontStyle.Regular, GraphicsUnit.Point);
            txtBoxGanado.Location = new Point(150, 408);
            txtBoxGanado.Multiline = true;
            txtBoxGanado.Name = "txtBoxGanado";
            txtBoxGanado.Size = new Size(142, 54);
            txtBoxGanado.TabIndex = 10;
            txtBoxGanado.Text = "0";
            txtBoxGanado.TextAlign = HorizontalAlignment.Right;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 27.75F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(12, 9);
            label1.Name = "label1";
            label1.Size = new Size(144, 50);
            label1.TabIndex = 11;
            label1.Text = "Loteria";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label3.Location = new Point(180, 384);
            label3.Name = "label3";
            label3.Size = new Size(66, 21);
            label3.TabIndex = 13;
            label3.Text = "Ganado";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            label6.Location = new Point(173, 281);
            label6.Name = "label6";
            label6.Size = new Size(78, 20);
            label6.TabIndex = 21;
            label6.Text = "Random 2";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(310, 4);
            label2.Name = "label2";
            label2.Size = new Size(64, 20);
            label2.TabIndex = 22;
            label2.Text = "Apuesta";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            label7.Location = new Point(26, 281);
            label7.Name = "label7";
            label7.Size = new Size(78, 20);
            label7.TabIndex = 24;
            label7.Text = "Random 3";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            label8.Location = new Point(318, 281);
            label8.Name = "label8";
            label8.Size = new Size(76, 20);
            label8.TabIndex = 26;
            label8.Text = "Random 1";
            // 
            // textBox1
            // 
            textBox1.Font = new Font("Segoe UI", 27.75F, FontStyle.Regular, GraphicsUnit.Point);
            textBox1.Location = new Point(289, 143);
            textBox1.MaxLength = 2;
            textBox1.Multiline = true;
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(75, 60);
            textBox1.TabIndex = 27;
            textBox1.Text = "00";
            textBox1.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox2
            // 
            textBox2.Font = new Font("Segoe UI", 27.75F, FontStyle.Regular, GraphicsUnit.Point);
            textBox2.Location = new Point(134, 143);
            textBox2.MaxLength = 2;
            textBox2.Multiline = true;
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(75, 60);
            textBox2.TabIndex = 31;
            textBox2.Text = "00";
            textBox2.TextAlign = HorizontalAlignment.Center;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            label9.Location = new Point(161, 120);
            label9.Name = "label9";
            label9.Size = new Size(17, 20);
            label9.TabIndex = 32;
            label9.Text = "2";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            label4.Location = new Point(317, 120);
            label4.Name = "label4";
            label4.Size = new Size(15, 20);
            label4.TabIndex = 28;
            label4.Text = "1";
            label4.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point);
            label11.Location = new Point(261, 31);
            label11.Name = "label11";
            label11.Size = new Size(25, 30);
            label11.TabIndex = 34;
            label11.Text = "$";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Segoe UI", 21.75F, FontStyle.Bold, GraphicsUnit.Point);
            label10.Location = new Point(113, 415);
            label10.Name = "label10";
            label10.Size = new Size(34, 40);
            label10.TabIndex = 35;
            label10.Text = "$";
            // 
            // btnPlay
            // 
            btnPlay.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            btnPlay.Location = new Point(173, 221);
            btnPlay.Name = "btnPlay";
            btnPlay.Size = new Size(75, 40);
            btnPlay.TabIndex = 36;
            btnPlay.Text = "JUGAR!";
            btnPlay.UseVisualStyleBackColor = true;
            btnPlay.Click += btnPlay_Click;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(rdbtnPale);
            groupBox1.Controls.Add(rdbtnPaleDoble);
            groupBox1.Location = new Point(48, 82);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(326, 35);
            groupBox1.TabIndex = 37;
            groupBox1.TabStop = false;
            // 
            // rdbtnPale
            // 
            rdbtnPale.AutoSize = true;
            rdbtnPale.Checked = true;
            rdbtnPale.Location = new Point(253, 10);
            rdbtnPale.Name = "rdbtnPale";
            rdbtnPale.Size = new Size(47, 19);
            rdbtnPale.TabIndex = 1;
            rdbtnPale.TabStop = true;
            rdbtnPale.Text = "Pale";
            rdbtnPale.UseVisualStyleBackColor = true;
            // 
            // rdbtnPaleDoble
            // 
            rdbtnPaleDoble.AutoSize = true;
            rdbtnPaleDoble.Location = new Point(36, 11);
            rdbtnPaleDoble.Name = "rdbtnPaleDoble";
            rdbtnPaleDoble.Size = new Size(81, 19);
            rdbtnPaleDoble.TabIndex = 0;
            rdbtnPaleDoble.TabStop = true;
            rdbtnPaleDoble.Text = "Doble Pale";
            rdbtnPaleDoble.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            label5.Location = new Point(53, 120);
            label5.Name = "label5";
            label5.Size = new Size(17, 20);
            label5.TabIndex = 39;
            label5.Text = "3";
            // 
            // textBox3
            // 
            textBox3.Font = new Font("Segoe UI", 27.75F, FontStyle.Regular, GraphicsUnit.Point);
            textBox3.Location = new Point(26, 143);
            textBox3.MaxLength = 2;
            textBox3.Multiline = true;
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(75, 60);
            textBox3.TabIndex = 38;
            textBox3.Text = "00";
            textBox3.TextAlign = HorizontalAlignment.Center;
            // 
            // labelResultado3
            // 
            labelResultado3.AutoSize = true;
            labelResultado3.Font = new Font("Segoe UI", 26.25F, FontStyle.Regular, GraphicsUnit.Point);
            labelResultado3.Location = new Point(33, 317);
            labelResultado3.Name = "labelResultado3";
            labelResultado3.Size = new Size(58, 47);
            labelResultado3.TabIndex = 41;
            labelResultado3.Text = "00";
            // 
            // labelResultado2
            // 
            labelResultado2.AutoSize = true;
            labelResultado2.Font = new Font("Segoe UI", 26.25F, FontStyle.Regular, GraphicsUnit.Point);
            labelResultado2.Location = new Point(183, 317);
            labelResultado2.Name = "labelResultado2";
            labelResultado2.Size = new Size(58, 47);
            labelResultado2.TabIndex = 44;
            labelResultado2.Text = "00";
            // 
            // labelResultado1
            // 
            labelResultado1.AutoSize = true;
            labelResultado1.Font = new Font("Segoe UI", 26.25F, FontStyle.Regular, GraphicsUnit.Point);
            labelResultado1.Location = new Point(325, 317);
            labelResultado1.Name = "labelResultado1";
            labelResultado1.Size = new Size(58, 47);
            labelResultado1.TabIndex = 45;
            labelResultado1.Text = "00";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(426, 490);
            Controls.Add(labelResultado1);
            Controls.Add(labelResultado2);
            Controls.Add(labelResultado3);
            Controls.Add(label5);
            Controls.Add(textBox3);
            Controls.Add(groupBox1);
            Controls.Add(btnPlay);
            Controls.Add(label10);
            Controls.Add(label11);
            Controls.Add(label9);
            Controls.Add(textBox2);
            Controls.Add(label4);
            Controls.Add(textBox1);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label2);
            Controls.Add(label6);
            Controls.Add(label3);
            Controls.Add(label1);
            Controls.Add(txtBoxGanado);
            Controls.Add(txtBoxApostado);
            Name = "Form1";
            Text = "Form1";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private TextBox txtBoxApostado;
        private TextBox txtBoxGanado;
        private Label label1;
        private Label label3;
        private Label label6;
        private Label label2;
        private Label label7;
        private Label label8;
        private TextBox textBox1;
        private TextBox textBox2;
        private Label label9;
        private Label label4;
        private Label label11;
        private Label label10;
        private Button btnPlay;
        private GroupBox groupBox1;
        private RadioButton rdbtnPale;
        private RadioButton rdbtnPaleDoble;
        private Label label5;
        private TextBox textBox3;
        private Label labelResultado3;
        private Label labelResultado2;
        private Label labelResultado1;
    }
}